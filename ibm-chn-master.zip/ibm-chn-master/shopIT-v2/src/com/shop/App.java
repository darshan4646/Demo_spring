package com.shop;

import com.shop.bill.BillingImpl;
import com.shop.pm.PriceMatrix;
import com.shop.pm.PriceMatrixImpl_v1;
import com.shop.pm.PriceMatrixImpl_v2;

public class App {

	public static void main(String[] args) {

		// init
		PriceMatrix v1=new PriceMatrixImpl_v1();
		PriceMatrix v2=new PriceMatrixImpl_v2();
		BillingImpl billing = new BillingImpl(v2);

		// use
		String[] cart = { "324567", "4356789" };
		double total = billing.geTotalPrice(cart);
		System.out.println("Total :" + total);

		// destroy
		// ..

	}

}
